#------------------------------------------------#
#   save_pcap.py                                 #
#                                                #
#   Save packets in PCAP for transfer over VMs   #
#                                                #
#   Kartik Chitturi <kchittur@andrew.cmu.edu>    #
#------------------------------------------------#

import os
import sys
import subprocess
import time
from scapy.all import *


pcap_filename = 'transfer.pcap'

FIN_MASK = 0x2
ACK_MASK = 0x4
SYN_MASK = 0x8

DATA_ACK_MASK = ACK_MASK

MAX_ADV_WINDOW = 2**32-1

class CMUTCP(Packet):
    name = "CMU TCP"
    fields_desc=[IntField("identifier",15441),
                 ShortField("source_port", 15441),
                 ShortField("destination_port", 15441),
                 IntField("seq_num",0),
                 IntField("ack_num",0),
                 ShortField("hlen",25),
                 ShortField("plen",25),
                 ByteEnumField("flags" , DATA_ACK_MASK,
                      { FIN_MASK: "FIN",
                        ACK_MASK: "ACK" ,
                        SYN_MASK: "SYN" ,
                        FIN_MASK | ACK_MASK: "FIN ACK",
                        SYN_MASK | ACK_MASK: "SYN ACK"} ),
                 IntField("advertised_window",MAX_ADV_WINDOW),
                 ShortField("extension_length",0),
                 StrLenField("extension_data", None,
                            length_from=lambda pkt: pkt.extension_length)]

    def answers(self, other):
        return isinstance(other, CMUTCP) and not (ICMP in other) and not (ICMP in self)

def get_cmu(pkt):
    if pkt is None or Raw not in pkt:
        return None
    try: 
        return CMUTCP(pkt[Raw])
    except:
        return None

def capture_packets():
    # Check if running as root
    if(os.geteuid() != 0):
        print("Need to run script using sudo")
        return
    
    sniffer = AsyncSniffer(iface='enp0s8')
    sniffer.start()
    print("Started capture")   
    input("Press ENTER to stop capture...")
    sniffer.stop()	 
    pkts = sniffer.results
    cmu_pkts = []
    for pkt in pkts:
        cpkt = get_cmu(pkt)
        if cpkt is not None:
            wrpcap(pcap_filename, pkt, append=True)

def get_adv_windows(num_pkts):
    pkts = rdpcap(pcap_filename)
    count = 0
    for pkt in pkts:
        cpkt = get_cmu(pkt)
        if cpkt is not None:
            print(cpkt.advertised_window)
            count += 1
        if count == num_pkts:
            break 

if __name__ == "__main__":
    capture_packets()
    get_adv_windows(5)
